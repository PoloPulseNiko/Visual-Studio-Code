function editElement(element, match, replacer) {
    let text = element.textContent;
    let regex = new RegExp(match, 'g'); // Create a global regular expression to match all occurrences
    text = text.replace(regex, replacer); // Replace all occurrences of the match with the replacer
    element.textContent = text; // Update the element's text content with the modified text
}
